import { useState } from 'react';
import { Package } from '../types';
import TrackingTimeline from './TrackingTimeline';
import { Box } from 'lucide-react';

interface Props {
  packages: Package[];
  onCancelStatus?: (status: any) => void;
}

export default function PackagesComparison({ packages, onCancelStatus }: Props) {
  const [selectedPackages, setSelectedPackages] = useState<string[]>([]);

  const togglePackageSelection = (packageCode: string) => {
    setSelectedPackages(prev => {
      if (prev.includes(packageCode)) {
        return prev.filter(code => code !== packageCode);
      }
      if (prev.length < 2) {
        return [...prev, packageCode];
      }
      return [prev[1], packageCode];
    });
  };

  const selectedPackagesList = packages.filter(pkg => 
    selectedPackages.includes(pkg.package_code)
  );

  return (
    <div className="space-y-6">
      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Selecciona hasta 2 bultos para comparar
        </h3>
        <div className="flex flex-wrap gap-2">
          {packages.map((pkg) => (
            <button
              key={pkg.package_code}
              onClick={() => togglePackageSelection(pkg.package_code)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-colors
                ${selectedPackages.includes(pkg.package_code)
                  ? 'bg-corporate-primary text-white border-corporate-primary'
                  : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'}`}
            >
              <Box className="w-4 h-4" />
              <span>Bulto {pkg.package_number}</span>
            </button>
          ))}
        </div>
      </div>

      {selectedPackagesList.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {selectedPackagesList.map((pkg) => (
            <div key={pkg.package_code} className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
              <div className="flex items-center gap-2 mb-4">
                <Box className="w-5 h-5 text-corporate-primary" />
                <div>
                  <h3 className="text-lg font-semibold text-corporate-primary">
                    Bulto {pkg.package_number}
                  </h3>
                  <p className="text-sm text-gray-600">
                    Código: {pkg.package_code}
                  </p>
                </div>
              </div>
              <TrackingTimeline
                events={pkg.events}
                onCancelStatus={onCancelStatus}
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}