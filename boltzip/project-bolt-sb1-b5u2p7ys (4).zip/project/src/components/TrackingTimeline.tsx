import { ShippingEvent } from '../types';
import { MapPin, Package, Truck, CheckCircle2 } from 'lucide-react';

interface Props {
  events: ShippingEvent[];
}

const getEventIcon = (type: string) => {
  switch (type) {
    case 'SHIPPING_ITEM_EVENT_V1':
      return <Package className="w-6 h-6 text-red-800" />;
    case 'PACKAGE_EVENT':
      return <Truck className="w-6 h-6 text-red-800" />;
    case 'NOTIFICATION_V1':
      return <MapPin className="w-6 h-6 text-red-800" />;
    default:
      return <CheckCircle2 className="w-6 h-6 text-red-800" />;
  }
};

export default function TrackingTimeline({ events }: Props) {
  const sortedEvents = [...events].sort((a, b) => 
    new Date(b.event_date).getTime() - new Date(a.event_date).getTime()
  );

  return (
    <div className="w-full">
      <div className="relative">
        {sortedEvents.map((event, index) => (
          <div key={index} className="mb-8 flex gap-4">
            <div className="flex-shrink-0 mt-1">
              {getEventIcon(event.type)}
            </div>
            <div className="flex-grow">
              <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
                <p className="font-semibold text-red-900">{event.description}</p>
                <p className="text-sm text-gray-600">
                  {new Date(event.event_date).toLocaleString('es-ES')}
                </p>
                {event.detail?.event_text && (
                  <p className="text-sm text-gray-700 mt-1">{event.detail.event_text}</p>
                )}
                {event.detail?.signee_name && (
                  <p className="text-sm text-gray-700 mt-1">
                    Firmado por: {event.detail.signee_name}
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}