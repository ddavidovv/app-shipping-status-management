import { ShippingEvent } from '../types';
import { Mail, Package, Truck, CheckCircle2, ChevronDown, ChevronRight } from 'lucide-react';
import { useState } from 'react';

interface Props {
  events: ShippingEvent[];
}

const getEventIcon = (type: string) => {
  switch (type) {
    case 'NOTIFICATION_V1':
      return <Mail className="w-5 h-5 text-red-800" />;
    case 'PACKAGE_EVENT':
      return <Truck className="w-5 h-5 text-red-800" />;
    default:
      return <CheckCircle2 className="w-5 h-5 text-red-800" />;
  }
};

interface GroupedEvents {
  mainEvent: ShippingEvent;
  subEvents: ShippingEvent[];
}

export default function TrackingTimeline({ events }: Props) {
  const [expandedStates, setExpandedStates] = useState<Record<number, boolean>>({});

  const toggleState = (index: number) => {
    setExpandedStates(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  const groupedEvents: GroupedEvents[] = events
    .filter(event => event.type === 'ITEM_STATUS_V2')
    .map(mainEvent => {
      const relatedEvents = events.filter(event => 
        new Date(event.event_date).getTime() <= new Date(mainEvent.event_date).getTime() &&
        new Date(event.event_date).getTime() > (
          events.find(e => 
            e.type === 'ITEM_STATUS_V2' && 
            new Date(e.event_date).getTime() < new Date(mainEvent.event_date).getTime()
          )?.event_date 
            ? new Date(events.find(e => 
                e.type === 'ITEM_STATUS_V2' && 
                new Date(e.event_date).getTime() < new Date(mainEvent.event_date).getTime()
              )!.event_date).getTime()
            : 0
        ) &&
        (event.type === 'NOTIFICATION_V1' || event.type === 'PACKAGE_EVENT')
      );

      return {
        mainEvent,
        subEvents: relatedEvents.sort((a, b) => 
          new Date(b.event_date).getTime() - new Date(a.event_date).getTime()
        )
      };
    })
    .sort((a, b) => 
      new Date(b.mainEvent.event_date).getTime() - new Date(a.mainEvent.event_date).getTime()
    );

  return (
    <div className="w-full space-y-2">
      {groupedEvents.map(({ mainEvent, subEvents }, index) => (
        <div key={index} className="space-y-1">
          {/* Estado principal */}
          <button 
            onClick={() => toggleState(index)}
            className="w-full flex items-center gap-3 bg-white px-3 py-2 rounded border border-gray-100 hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center gap-3 flex-1">
              <CheckCircle2 className="w-5 h-5 text-red-800 flex-shrink-0" />
              <span className="text-sm text-gray-600 font-medium min-w-36">
                {new Date(mainEvent.event_date).toLocaleString('es-ES')}
              </span>
              <span className="text-sm text-red-900 font-semibold">
                {mainEvent.description}
              </span>
            </div>
            {subEvents.length > 0 && (
              <div className="flex items-center gap-1 text-gray-500">
                <span className="text-xs">
                  {subEvents.length} {subEvents.length === 1 ? 'evento' : 'eventos'}
                </span>
                {expandedStates[index] ? (
                  <ChevronDown className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
              </div>
            )}
          </button>

          {/* Subeventos */}
          {expandedStates[index] && subEvents.length > 0 && (
            <div className="ml-8 space-y-1">
              {subEvents.map((event, subIndex) => (
                <div 
                  key={`${index}-${subIndex}`} 
                  className="flex items-center gap-3 bg-gray-50 px-3 py-2 rounded border border-gray-100"
                >
                  {getEventIcon(event.type)}
                  <span className="text-sm text-gray-600 font-medium min-w-36">
                    {new Date(event.event_date).toLocaleString('es-ES')}
                  </span>
                  <div className="flex-1">
                    <span className="text-sm text-gray-900">
                      {event.description}
                    </span>
                    {event.detail?.event_text && (
                      <span className="text-sm text-gray-600 ml-2">
                        ({event.detail.event_text})
                      </span>
                    )}
                    {event.detail?.signee_name && (
                      <span className="text-sm text-gray-600 ml-2">
                        (Firmado por: {event.detail.signee_name})
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}