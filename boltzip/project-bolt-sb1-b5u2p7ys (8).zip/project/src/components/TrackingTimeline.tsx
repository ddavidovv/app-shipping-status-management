import { ShippingEvent } from '../types';
import { Mail, Package, Truck, CheckCircle2, ChevronDown, ChevronRight, XCircle, Ban } from 'lucide-react';
import { useState } from 'react';
import { isEventCancellable } from '../config/eventConfig';

interface Props {
  events: ShippingEvent[];
  onCancelEvent?: (event: ShippingEvent) => void;
}

const getEventIcon = (type: string) => {
  switch (type) {
    case 'NOTIFICATION_V1':
      return <Mail className="w-5 h-5 text-red-800" />;
    case 'PACKAGE_EVENT':
      return <Truck className="w-5 h-5 text-red-800" />;
    default:
      return <CheckCircle2 className="w-5 h-5 text-red-800" />;
  }
};

interface GroupedEvents {
  status: ShippingEvent;
  events: ShippingEvent[];
}

export default function TrackingTimeline({ events, onCancelEvent }: Props) {
  const [expandedStates, setExpandedStates] = useState<Record<string, boolean>>({});
  const [showNotifications, setShowNotifications] = useState(true);

  const toggleState = (statusDate: string) => {
    setExpandedStates(prev => ({
      ...prev,
      [statusDate]: !prev[statusDate]
    }));
  };

  // Separar notificaciones y estados
  const notifications = events
    .filter(event => event.type === 'NOTIFICATION_V1')
    .sort((a, b) => new Date(b.event_date).getTime() - new Date(a.event_date).getTime());

  // Filtrar y ordenar los estados (ITEM_STATUS_V2)
  const statusEvents = events
    .filter(event => event.type === 'ITEM_STATUS_V2')
    .sort((a, b) => new Date(b.event_date).getTime() - new Date(a.event_date).getTime());

  // Agrupar solo eventos de paquete por estado
  const groupedEvents: GroupedEvents[] = statusEvents.map((status, index) => {
    const nextStatus = statusEvents[index + 1];
    const currentStatusDate = new Date(status.event_date).getTime();
    const nextStatusDate = nextStatus 
      ? new Date(nextStatus.event_date).getTime() 
      : 0;

    // Filtrar solo eventos de paquete entre estados
    const packageEvents = events.filter(event => {
      const eventDate = new Date(event.event_date).getTime();
      return (
        eventDate <= currentStatusDate &&
        eventDate > nextStatusDate &&
        event.type === 'PACKAGE_EVENT'
      );
    }).sort((a, b) => new Date(b.event_date).getTime() - new Date(a.event_date).getTime());

    return {
      status,
      events: packageEvents
    };
  });

  return (
    <div className="w-full space-y-2">
      {/* Estados y sus eventos */}
      {groupedEvents.map(({ status, events: packageEvents }) => (
        <div key={status.event_date} className="space-y-1">
          <button 
            onClick={() => toggleState(status.event_date)}
            className="w-full flex items-center gap-3 bg-white px-3 py-2 rounded border border-gray-100 hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center gap-3 flex-1">
              <CheckCircle2 className="w-5 h-5 text-red-800 flex-shrink-0" />
              <span className="text-sm text-gray-600 font-medium min-w-36">
                {new Date(status.event_date).toLocaleString('es-ES')}
              </span>
              <span className="text-sm text-red-900 font-semibold">
                {status.description}
              </span>
            </div>
            {packageEvents.length > 0 && (
              <div className="flex items-center gap-1 text-gray-500">
                <span className="text-xs">
                  {packageEvents.length} {packageEvents.length === 1 ? 'evento' : 'eventos'}
                </span>
                {expandedStates[status.event_date] ? (
                  <ChevronDown className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
              </div>
            )}
          </button>

          {/* Eventos del estado */}
          {expandedStates[status.event_date] && packageEvents.length > 0 && (
            <div className="ml-8 space-y-1">
              {packageEvents.map((event, index) => {
                const isCancellable = isEventCancellable(event.type);
                return (
                  <div 
                    key={`${status.event_date}-${index}`} 
                    className="flex items-center gap-3 bg-gray-50 px-3 py-2 rounded border border-gray-100"
                  >
                    <div className="flex-1 flex items-center gap-3">
                      <Truck className="w-5 h-5 text-red-800" />
                      <span className="text-sm text-gray-600 font-medium min-w-36">
                        {new Date(event.event_date).toLocaleString('es-ES')}
                      </span>
                      <div>
                        <span className="text-sm text-gray-900">
                          {event.description}
                        </span>
                        {event.detail?.event_text && (
                          <span className="text-sm text-gray-600 ml-2">
                            ({event.detail.event_text})
                          </span>
                        )}
                        {event.detail?.signee_name && (
                          <span className="text-sm text-gray-600 ml-2">
                            (Firmado por: {event.detail.signee_name})
                          </span>
                        )}
                      </div>
                    </div>
                    {onCancelEvent && (
                      isCancellable ? (
                        <button
                          onClick={() => onCancelEvent(event)}
                          className="p-1 text-gray-500 hover:text-red-600 transition-colors"
                          title="Anular evento"
                        >
                          <XCircle className="w-5 h-5" />
                        </button>
                      ) : (
                        <span
                          className="p-1 text-gray-400"
                          title="Este tipo de evento no se puede anular"
                        >
                          <Ban className="w-5 h-5" />
                        </span>
                      )
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ))}

      {/* Sección de notificaciones */}
      <button 
        onClick={() => setShowNotifications(!showNotifications)}
        className="w-full flex items-center gap-3 bg-white px-3 py-2 rounded border border-gray-100 hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-center gap-3 flex-1">
          <Mail className="w-5 h-5 text-red-800 flex-shrink-0" />
          <span className="text-sm text-red-900 font-semibold">
            Notificaciones
          </span>
        </div>
        <div className="flex items-center gap-1 text-gray-500">
          <span className="text-xs">
            {notifications.length} {notifications.length === 1 ? 'notificación' : 'notificaciones'}
          </span>
          {showNotifications ? (
            <ChevronDown className="w-4 h-4" />
          ) : (
            <ChevronRight className="w-4 h-4" />
          )}
        </div>
      </button>

      {/* Lista de notificaciones */}
      {showNotifications && notifications.length > 0 && (
        <div className="ml-8 space-y-1">
          {notifications.map((notification, index) => (
            <div 
              key={`notification-${index}`}
              className="flex items-center gap-3 bg-gray-50 px-3 py-2 rounded border border-gray-100"
            >
              <Mail className="w-5 h-5 text-red-800" />
              <span className="text-sm text-gray-600 font-medium min-w-36">
                {new Date(notification.event_date).toLocaleString('es-ES')}
              </span>
              <span className="text-sm text-gray-900">
                {notification.description}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}