export const CANCELLABLE_EVENT_TYPES = [
  'SORTER_READ_EVENT',
  'MANUAL_SCAN',
  'PACKAGE_EVENT'
];

// Función helper para verificar si un evento es anulable
export const isEventCancellable = (eventType: string): boolean => {
  return CANCELLABLE_EVENT_TYPES.includes(eventType);
};