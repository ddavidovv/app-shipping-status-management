// Simulación de endpoints para eventos
export const eventService = {
  async createEvent(eventData: any) {
    // Simular llamada al backend
    console.log('Creating event:', eventData);
    
    // Simular delay de red
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Simular respuesta exitosa
    return {
      success: true,
      data: {
        ...eventData,
        id: crypto.randomUUID()
      }
    };
  },

  async cancelEvent(eventId: string, reason: string) {
    // Simular llamada al backend
    console.log('Cancelling event:', { eventId, reason });
    
    // Simular delay de red
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Simular respuesta exitosa
    return {
      success: true,
      data: {
        eventId,
        cancellationReason: reason,
        cancelledAt: new Date().toISOString()
      }
    };
  }
};