import { ShippingData } from '../types';
import { MapPin, User, Package } from 'lucide-react';

interface Props {
  data: ShippingData;
}

export default function ShipmentDetails({ data }: Props) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-semibold text-red-900 mb-4 flex items-center gap-2">
            <Package className="w-5 h-5" />
            Detalles del envío
          </h3>
          <p className="text-sm text-gray-600 mb-2">
            Número de envío: {data.shipping_code}
          </p>
          <p className="text-sm text-gray-600 mb-2">
            Estado: {data.last_shipping_status_code}
          </p>
        </div>
        
        <div className="space-y-6">
          <div>
            <h4 className="text-md font-semibold text-red-900 mb-2 flex items-center gap-2">
              <User className="w-5 h-5" />
              Remitente
            </h4>
            <p className="text-sm text-gray-600">{data.sender_name}</p>
            <p className="text-sm text-gray-600">{data.sender_address}</p>
          </div>
          
          <div>
            <h4 className="text-md font-semibold text-red-900 mb-2 flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Destinatario
            </h4>
            <p className="text-sm text-gray-600">{data.recipient_name}</p>
            <p className="text-sm text-gray-600">{data.recipient_address}</p>
          </div>
        </div>
      </div>
    </div>
  );
}