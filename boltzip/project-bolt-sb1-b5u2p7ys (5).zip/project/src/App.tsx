import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { ShippingData } from './types';
import TrackingTimeline from './components/TrackingTimeline';
import ShipmentDetails from './components/ShipmentDetails';

function App() {
  const [trackingNumber, setTrackingNumber] = useState('');
  const [shipmentData, setShipmentData] = useState<ShippingData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async () => {
    if (!trackingNumber.trim()) return;
    
    setLoading(true);
    setError('');
    
    try {
      const response = await fetch(`/api/item-history-api/v1/history/${trackingNumber}?view=unfiltered&show_items=false`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: '',
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result = await response.json();
      
      if (result.error) {
        setError('No se pudo encontrar el envío');
        setShipmentData(null);
      } else {
        setShipmentData(result.data);
      }
    } catch (err) {
      console.error('Error:', err);
      setError('Error al buscar el envío');
      setShipmentData(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-red-900 mb-8 text-center">
          Seguimiento de Envíos
        </h1>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 mb-8">
          <div className="flex gap-4">
            <input
              type="text"
              value={trackingNumber}
              onChange={(e) => setTrackingNumber(e.target.value)}
              placeholder="Introduce tu número de seguimiento"
              className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
            />
            <button
              onClick={handleSearch}
              disabled={loading}
              className="px-6 py-2 bg-red-900 text-white rounded-lg hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-red-500 flex items-center gap-2 disabled:opacity-50"
            >
              <Search className="w-5 h-5" />
              {loading ? 'Buscando...' : 'Buscar'}
            </button>
          </div>
          
          {error && (
            <p className="text-red-600 mt-4">{error}</p>
          )}
        </div>

        {shipmentData && (
          <div className="space-y-8">
            <ShipmentDetails data={shipmentData} />
            <TrackingTimeline events={shipmentData.shipping_history.events} />
          </div>
        )}
      </div>
    </div>
  );
}

export default App;